import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.DefaultListModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.datatransfer.DataFlavor;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class View {

	private JFrame frame;
	private JList<String> list;
	private JList<String> description;
	private DefaultListModel <String> listModel;
	private DefaultListModel <String> descriptionModel;
	private Controller c;


	public View(Controller c) {
		this.c = c;
		initialize();
		this.frame.setVisible(true);
		
	}
	
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		
		
		frame.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent arg0) {
				closingEvent();
			}
		});
		
	
		frame.setSize(800, 800);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		listModel= new DefaultListModel<String>();
		descriptionModel = new DefaultListModel<String>();
		
		frame.getContentPane().setLayout(new FlowLayout(FlowLayout.LEFT, 5, 5));
			
		list = new JList<String>();
		description = new JList<String>();
		
		description.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				if (arg0.getButton() == MouseEvent.BUTTON3){
				if (description.getSelectedValue() != null){
					String result = JOptionPane.showInputDialog("new value");
					if(result != null)
					if (!result.equals(""))
					descriptionModel.set(description.getSelectedIndex(), result);
					
				}
				description.clearSelection();
				}
			}
		});
		
		
		list.setVisibleRowCount(15);
		
		list.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				if (arg0.getButton() == MouseEvent.BUTTON3){
					System.out.println("pressed left mouse");
					try {
						String data = (String) Toolkit.getDefaultToolkit()
								 .getSystemClipboard()
								 .getData(DataFlavor.stringFlavor);
												
						listModel.addElement(data);
						descriptionModel.addElement("none");
					}  catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				
					
				
			}else if (arg0.getButton() == MouseEvent.BUTTON1) {
				System.out.println("pressed right mouse");
				if (list.getSelectedValue() != null){
					c.work(list.getSelectedValue());
				}
			}
			}
		});
	
		list.setModel(listModel);
		description.setModel(descriptionModel);
		
		frame.getContentPane().add(list);
		frame.getContentPane().add(description);
		
	
		
		//frame.pack();
		
	
		
	}

	public JList<String> getList() {
		return list;
	}

	public DefaultListModel<String> getDescriptionModel() {
		return descriptionModel;
	}

	public DefaultListModel<String> getListModel() {
		return listModel;
	}

	public void addElementToListModel(String s){
		listModel.addElement(s);
	}
	
	public void addElementToDescriptionModel(String s){
		descriptionModel.addElement(s);
	}
	
	private void closingEvent(){
	c.viewClosing(this);	
	}
	

}
