import java.awt.Desktop;
import java.io.File;
import java.net.URI;
import java.util.ArrayList;
import java.util.Collections;

import javax.swing.JOptionPane;

public class Controller {
	Datamanagement dataman;
	Kryptomanagement kryptoman;
	Model model;
	View view;
	//String strKey = "9ypBmEeH*MbQeThW";
	String strKey;
	
	
	public Controller() {
		
		strKey = JOptionPane.showInputDialog("enter key");
		dataman = new Datamanagement();
		kryptoman = new Kryptomanagement();
		
		model = dataman.retrieve();
		if(model == null){
		model = new Model();
		encryptAll();
		dataman.save(model);
		}
		decryptAll();
		view = new View(this);
		
		//fill view model with each element of model arraylist
		for (String s : model.getList()) {
		view.addElementToListModel(s);	
		}
		
		for (String s : model.getDescription()) {
		view.addElementToDescriptionModel(s);
		}
}
	
public void viewClosing(View v){
	ArrayList<String> arrayList = Collections.list(view.getListModel().elements());
	ArrayList<String> descriptionList = Collections.list(view.getDescriptionModel().elements());
	model.setList(arrayList);
	model.setDescription(descriptionList);
	
	encryptAll();
	dataman.save(model);
}

public void work(String s){
view.getList().clearSelection();
retrieveURI(s);	
	
}

public void retrieveURI(String s){
try {
	//System.out.println(stars.getItemFormArrayList());	
	ProcessBuilder builder = new ProcessBuilder( "cmd", "/c", "start chrome.exe --new-tab \"http://google.de\" --new-tab \"http://golem.de\"" );
	builder.directory( new File("C:/Program Files (x86)/Google/Chrome/Application") );
	builder.start();

	Desktop.getDesktop().browse(new URI(s));
	
} catch (Exception e) {
	// TODO: handle exception
	e.printStackTrace();
	
}
}

public void encryptAll(){
	ArrayList<String> enal = new ArrayList<String>();
	ArrayList<String> enaldes = new ArrayList<String>();
	for (String s : model.getList()) {
		//System.out.println("$plain:"+s);
		//System.out.println("$encrypted:"+kryptoman.encrypt(s, strKey));
		enal.add(kryptoman.encrypt(s, strKey));
	}
	for (String s : model.getDescription()) {
		//System.out.println("$plain:"+s);
		//System.out.println("$encrypted:"+kryptoman.encrypt(s, strKey));
		enaldes.add(kryptoman.encrypt(s, strKey));
	}
	model.setList(enal);
	model.setDescription(enaldes);
	System.out.println("encrypted!");
}

public void decryptAll(){
	ArrayList<String> deal = new ArrayList<String>();
	ArrayList<String> dealdes = new ArrayList<String>();
	for (String s : model.getList()) {
		//System.out.println("$encrypted:"+s);
		//System.out.println("$plain:"+kryptoman.decrypt(s, strKey));
		deal.add(kryptoman.decrypt(s, strKey));
	}
	for (String s : model.getDescription()) {
		//System.out.println("$encrypted:"+s);
		//System.out.println("$plain:"+kryptoman.decrypt(s, strKey));
		dealdes.add(kryptoman.decrypt(s, strKey));
	}
	model.setList(deal);
	model.setDescription(dealdes);
	System.out.println("decrypted!");
}
}
