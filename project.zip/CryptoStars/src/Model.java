import java.util.ArrayList;

public class Model  implements java.io.Serializable{

/**
	 * 
	 */
private static final long serialVersionUID = 1L;
private ArrayList<String> list;
private ArrayList<String> description;
	
public Model() {
	list = new ArrayList<String>();
	description = new ArrayList<String>();
	list.add("links");
	description.add("description");
}

public ArrayList<String> getDescription() {
	return description;
}

public ArrayList<String> getList() {
	return list;
}

public void setDescription(ArrayList<String> description) {
	this.description = description;
}

public void setList(ArrayList<String> list) {
	this.list = list;
}

}
