package test;

import java.io.UnsupportedEncodingException;
import java.util.Iterator;

public class test {

	public static void main(String[] args) throws UnsupportedEncodingException  {

	    String s = new String("nico");
	    		
	    	 for (Byte b : s.getBytes()) {
				System.out.println(b.toString());
			}
		
		} 
	
	

}
