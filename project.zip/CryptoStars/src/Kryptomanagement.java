import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import org.apache.commons.codec.binary.Hex;

public class Kryptomanagement {
	
	public  String encrypt(String strClearText,String strKey){
		String strData="";
		
		try {
			SecretKeySpec skeyspec=new SecretKeySpec(strKey.getBytes(),"Blowfish");
			Cipher cipher=Cipher.getInstance("Blowfish/ECB/PKCS5PADDING");
			cipher.init(Cipher.ENCRYPT_MODE, skeyspec);
			byte[] encrypted=cipher.doFinal(strClearText.getBytes());
			
			strData=Hex.encodeHexString(encrypted);
			
		} catch (Exception e) {
			e.printStackTrace();
			Runtime.getRuntime().exit(1);
					}
		return strData;
	}
	
	public  String decrypt(String strEncrypted,String strKey) {
		String strData="";
		
		try {
			SecretKeySpec skeyspec=new SecretKeySpec(strKey.getBytes(),"Blowfish");
			Cipher cipher=Cipher.getInstance("Blowfish/ECB/PKCS5PADDING");
			cipher.init(Cipher.DECRYPT_MODE, skeyspec);
			
			//byte[] decrypted=cipher.doFinal(strEncrypted.getBytes());
			byte[] decrypted=cipher.doFinal(Hex.decodeHex(strEncrypted));
			strData=new String(decrypted);
			
			
		} catch (Exception e) {
			e.printStackTrace();
			Runtime.getRuntime().exit(1);
			
					}
		return strData;
}
	
}
